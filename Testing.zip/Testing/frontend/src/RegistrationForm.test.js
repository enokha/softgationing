import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import RegistrationForm from './RegistrationForm';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

describe('Registration Form', () => {
    const mock = new MockAdapter(axios);

    it('allows a user to register successfully', async () => {
        mock.onPost('http://localhost:3000/api/users/register').reply(201, 'User registered');

        render(<RegistrationForm />);
        userEvent.type(screen.getByLabelText(/username/i), 'testuser');
        userEvent.type(screen.getByLabelText(/password/i), 'password123');
        fireEvent.click(screen.getByRole('button', { name: /register/i }));

        await waitFor(() => {
            expect(screen.getByText('User registered: User registered')).toBeInTheDocument();
        });
    });

    it('shows an error message on registration failure', async () => {
        mock.onPost('http://localhost:3000/api/users/register').networkError();

        render(<RegistrationForm />);
        userEvent.type(screen.getByLabelText(/username/i), 'testuser');
        userEvent.type(screen.getByLabelText(/password/i), 'password123');
        fireEvent.click(screen.getByRole('button', { name: /register/i }));

        await waitFor(() => {
            expect(screen.getByText('Registration failed. Please try again.')).toBeInTheDocument();
        });
    });
});