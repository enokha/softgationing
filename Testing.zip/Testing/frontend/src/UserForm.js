import React, { useState } from 'react';

function UserForm({ onSubmit }) {
    const [name, setName] = useState('');

    const handleSubmit = (event) => {
        event.preventDefault();
        onSubmit(name);
    };

    return (
        <form onSubmit={handleSubmit}>
            <label htmlFor="name">Name:</label>
            <input
                id="name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter user name"
            />
            <button type="submit">Submit</button>
        </form>
    );
}

export default UserForm;