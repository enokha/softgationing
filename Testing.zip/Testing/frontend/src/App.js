import React from 'react';
import RegistrationForm from './RegistrationForm';
import LoginForm from './LoginForm';

function App() {
  return (
      <div>
        <h1>Welcome to Our App</h1>
        <RegistrationForm />
        <LoginForm />
      </div>
  );
}

export default App;
