import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import LoginForm from './LoginForm';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

describe('Login Form', () => {
    const mock = new MockAdapter(axios);

    it('allows a user to log in successfully', async () => {
        const token = "testtoken123";
        mock.onPost('http://localhost:3000/api/users/login').reply(200, { accessToken: token });

        render(<LoginForm />);
        userEvent.type(screen.getByLabelText(/username/i), 'testuser');
        userEvent.type(screen.getByLabelText(/password/i), 'password123');
        fireEvent.click(screen.getByRole('button', { name: /login/i }));

        await waitFor(() => {
            expect(screen.getByText(`Login successful: {"accessToken":"${token}"}`)).toBeInTheDocument();
        });
    });

    it('shows an error message on login failure', async () => {
        mock.onPost('http://localhost:3000/api/users/login').networkError();

        render(<LoginForm />);
        userEvent.type(screen.getByLabelText(/username/i), 'testuser');
        userEvent.type(screen.getByLabelText(/password/i), 'password123');
        fireEvent.click(screen.getByRole('button', { name: /login/i }));

        await waitFor(() => {
            expect(screen.getByText('Login failed')).toBeInTheDocument();
        });
    });
});
