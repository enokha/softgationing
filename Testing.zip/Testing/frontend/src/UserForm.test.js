import { render, screen, fireEvent } from '@testing-library/react';
import UserForm from './UserForm';

describe('UserForm', () => {
    test('renders input correctly', () => {
        render(<UserForm onSubmit={() => {}} />);
        const input = screen.getByPlaceholderText('Enter user name');
        expect(input).toBeInTheDocument();
    });

    test('submits the form with the name', () => {
        const mockSubmit = jest.fn();
        render(<UserForm onSubmit={mockSubmit} />);
        const input = screen.getByPlaceholderText('Enter user name');
        const button = screen.getByRole('button', { name: 'Submit' });

        fireEvent.change(input, { target: { value: 'John Doe' } });
        fireEvent.click(button);

        expect(mockSubmit).toHaveBeenCalledWith('John Doe');
    });
});
